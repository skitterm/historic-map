//
//  HistoricalMapAppDelegate.h
//  HistoricalMap
//
//  Created by Student on 12/5/13.
//  Copyright (c) 2013 Student. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HistoricalMapAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
