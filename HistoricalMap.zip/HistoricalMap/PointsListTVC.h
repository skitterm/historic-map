//
//  PointsListTVC.h
//  HistoricalMap
//
//  Created by Student on 12/5/13.
//  Copyright (c) 2013 Student. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Places.h"

@interface PointsListTVC : UITableViewController

@property (strong, nonatomic) Places *places;

@end
