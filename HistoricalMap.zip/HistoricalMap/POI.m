//
//  POI.m
//  HistoricalMap
//
//  Created by Student on 12/7/13.
//  Copyright (c) 2013 Student. All rights reserved.
//

#import "POI.h"

@implementation POI


+ (NSArray *)validGenres {
    return @[@"Architecture", @"Food", @"Music", @"Outdoors", @"Historic"];
}

@end
