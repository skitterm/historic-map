//
//  Places.h
//  HistoricalMap
//
//  Created by Student on 12/7/13.
//  Copyright (c) 2013 Student. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import "POI.h"

@interface Places : NSObject

@property (strong, nonatomic) NSMutableArray *poiList;

@end
